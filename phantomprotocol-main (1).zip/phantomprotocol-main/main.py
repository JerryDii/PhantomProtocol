import sys

from imageassets.Aimages import *
import backstory
import bossfight
import healthbars
import loadingscreen
import mainmenu
import mobs
import player
import weapons

pygame.init()

screen = pygame.display.set_mode([1067, 600])
pygame.display.set_caption(" Phantom Protocol")
pygame.display.set_icon(phantomicon)
clock = pygame.time.Clock()
mainmenu.musicplay()

game = True

while game:
    # 1. main menu screen: function in mainmenu.py -----
    mainmenu.firstmenu(screen, clock)

    # prevents the game variables from resetting when the game is paused
    if not mainmenu.pause:
        # game variables can only be reset if the player dies or gives up or wins
        # 4. game screen -------------------------------
        fadescreen = True

        # backstory ------------------------------------
        backstory_begin = False
        complete_backstory = False

        # moving the player around by moving the screen
        x_screen = 0
        y_screen = 0
        jump = False
        # player hp bar moves up and down when walking
        walking = 0
        walkdown = False
        # player speed
        playerspeed = 10

        # controls the amount each item falls
        fall = 0

    # begin main game
    if not bossfight.bossfightbegin:
        done = False

    # main loop ----------------------------------------
    while not done:
        if healthbars.playerhp <= 0 or mainmenu.restart:
            # if the player dies or gives up in main menu
            # quit game, return to end screen, and main menu
            mainmenu.overscreen = True
            done = True
            mainmenu.finaltxt = True

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DELETE:
                    # resets the game from inside of the game loop/player gave up
                    mainmenu.overscreen = True
                    done = True
                    mainmenu.finaltxt = True

                elif event.key == pygame.K_ESCAPE and mainmenu.fade >= 258:
                    # pause the game only after the screen has faded out
                    mainmenu.pause = True
                    done = True

                if complete_backstory and event.key == pygame.K_e:
                    # press e to switch between weapons
                    if weapons.current_weapon == "sword":
                        weapons.current_weapon = "gun"
                    elif weapons.current_weapon == "gun":
                        weapons.current_weapon = "mouse"
                        pygame.mouse.set_visible(True)
                    elif weapons.current_weapon == "mouse":
                        weapons.current_weapon = "sword"

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # player has left clicked
                mouse = pygame.mouse.get_pos()
                print(mouse)

                if backstory_begin and mainmenu.fade == 300:
                    # main menu has to have faded away for backstory sequence to begin
                    # backstory sequence function in backstory.py
                    backstory.backstoryseq()

                    if backstory.backstorylist[6][0] is True:
                        # after the backstory has cycled to its last sentence
                        backstory_begin = False
                        complete_backstory = True

                # actual game controls
                elif complete_backstory:
                    # after backstory has been completed
                    if weapons.current_weapon == "gun" and len(weapons.bulletlist) <= 19:
                        # if there are 20 bullets shot then another round will be generated
                        # bullets are kept in a list and that list is appended based on the position of the gun
                        weapons.bulletlist.append([weapons.weaponx - x_screen + 15, weapons.weapony - 5])

                    # causes the weapon to lunge forward
                    weapons.swordforward = True
                    # weapon sfx
                    weapons.swordwoosh.play()

                    if len(mobs.itemdraw) == 2:
                        # if there is an already existing item spawned
                        if healthbars.itemrect.collidepoint(mouse) \
                                and weapons.current_weapon != "sword" and weapons.current_weapon != "gun":
                            # if mouse collides with an item
                            if mobs.dropkey == 1:
                                # random generated number chance
                                # add one extra key to the inventory
                                bossfight.key += 1

                            elif mobs.dropkey == 2:
                                # generate 50 hp
                                healthbars.healthpotion()

                            # clear all the variables for the next item to be spawned
                            mobs.itemdraw.clear()
                            fall, mobs.fallplace, mobs.dropkey = 0, 0, 0

                    # check if mob has been hit by cycling through the list with length of existing mobs
                    for hit in range(len(mobs.mobs_list_bot)):
                        mobs.mobhit(hit, x_screen)
                        if weapons.current_weapon == "sword":
                            # check if sword has collided with any of the mobs
                            weapons.checkhit(weapons.swordrect, hit, 8)

        # WASD
        if complete_backstory:
            # check to see if the key has been pressed and held
            movescreen = pygame.key.get_pressed()

            # jump only when the player is on the ground
            if movescreen[pygame.K_w] and player.pos_y == 390:
                jump = True

            # move to the left
            if movescreen[pygame.K_a]:
                # if player is not already where they spawned
                if x_screen < 0:
                    x_screen += playerspeed
                    # player running animation
                    player.player.run()
                    # controls up and down movement of hp bar
                    if not walkdown:
                        walking += 0.5
                else:
                    player.player.stoprun()

            # move to the right
            elif movescreen[pygame.K_d]:
                # if player is not touching the game boundaries
                if x_screen >= -2750:
                    x_screen -= playerspeed
                    player.player.run()
                    if not walkdown:
                        walking += 0.5
                else:
                    player.player.stoprun()

                if bossfight.key >= 5 and x_screen <= -2749:
                    bossfight.bossfightbegin = True
                    done = True

            else:
                player.player.stoprun()

        # checks for the position of the mouse and prints the sword based on it
        swordmouse = pygame.mouse.get_pos()
        weapons.weapony = swordmouse[1]
        # prevents the sword from being used beyond a certain boundary
        if 0 < swordmouse[0] > 326:
            weapons.weaponx = 326
        else:
            weapons.weaponx = swordmouse[0]

        # calcs ---------------------------------
        # set up fade screen from menu to game/backstory, and only runs on the first try of the game
        if fadescreen and not mainmenu.pause:
            loadingscreen.fade_template(mainmenu)

        # rectangle for collision detecting
        player_rect = pygame.Rect(122, player.pos_y + 10, 64, 160)

        # hp bar walking animation
        if walking > 2.5 and not walkdown:
            walkdown = True
        if walkdown:
            walking -= 0.7
            if walking <= 0:
                walkdown = False

        # if player jumps
        if jump:
            player.expo += 0.15
            player.pos_y -= 10 / player.expo
            if player.pos_y <= 200:
                player.expo = 0
                jump = False

        # player jump but the fall back down
        if not jump and player.pos_y != 390:
            player.pos_y += 10 * player.expo
            player.expo += 0.15
            if player.pos_y >= 400:
                player.pos_y = 390
                player.expo = 0

        # check if the mobs have collided with the user
        # cycles through for loop for the number of existing mobs
        if complete_backstory:
            for collide in range(len(mobs.mobs_list_bot)):
                mobs.mobhit(collide, x_screen)
                if mobs.mob_hpbot[collide]:
                    healthbars.mobdamage_place(player_rect, mobs.mob_rect_bot)
                if mobs.mob_hptop[collide]:
                    healthbars.mobdamage_place(player_rect, mobs.mob_rect_top)

        # if all the mobs are killed, they will be reset
        if not any(mobs.mob_hpbot) and not any(mobs.mob_hptop):
            # clear the previous list
            mobs.clearmobs()
            # recreate mobs
            mobs.mobcreation(mobs.mob_xtop, mobs.mob_ytop, mobs.mob_hptop, mobs.mobs_list_top)
            mobs.mobcreation(mobs.mob_xbot, mobs.mob_ybot, mobs.mob_hpbot, mobs.mobs_list_bot)

        # allows sword to make the stabbing motion if player clicks
        weapons.swordstab()

        glow.set_alpha(weapons.addglow)
        weapons.pulse()

        # check if mobs have been killed so they can drop a key
        mobs.checkmobkey()

        # draw -----------------------------------
        # draws main background
        screen.blit(hallwaybg, [x_screen, y_screen])

        # draw the mobs behind the player
        if any(mobs.mob_hpbot):
            mobs.bunch_of_mobs(screen, x_screen, mobs.mobs_list_bot, mobs.mob_xbot,
                               mobs.mob_ybot, mobs.mob_hpbot, RED, GREEN)

        # draw the items being dropped based on the pickup rate in mobs.py
        if len(mobs.itemdraw) == 2:
            if mobs.dropkey == 1:
                healthbars.itemdrop(keyimg, screen, mobs.itemdraw[0] + x_screen, mobs.itemdraw[1] + fall, 32, 15)
            if mobs.dropkey == 2:
                healthbars.itemdrop(potionimg, screen, mobs.itemdraw[0] + x_screen, mobs.itemdraw[1] + fall, 24, 27)
            # makes whatever item fall
            if mobs.itemdraw[1] + 12 + fall < mobs.fallplace:
                fall += 4

        # draw the player, player hp bar
        if complete_backstory:
            player.moving_sprites.draw(screen)
            player.moving_sprites.update(0.4, 0)
            healthbars.playerhpbar(screen, RED, GREEN, walking, 0)

            # draws the sword or gun
            if weapons.current_weapon == "sword":
                weapons.weaponchoice(screen, weapons.weaponx, weapons.weapony, daggerimg)
            elif weapons.current_weapon == "gun":
                weapons.weaponchoice(screen, weapons.weaponx, weapons.weapony, gunimg)

            # check if bullets have collided with a mob
            weapons.checkbullet(x_screen)
            weapons.bullets(screen, x_screen)

        # draw the mobs on top of the player
        if any(mobs.mob_hptop):
            mobs.bunch_of_mobs(screen, x_screen, mobs.mobs_list_top, mobs.mob_xtop,
                               mobs.mob_ytop, mobs.mob_hptop, RED, GREEN)

        # control speed of mob frame animation
        mobs.mobanimation += 0.5

        # backstory
        if backstory_begin and not complete_backstory:
            # controls the fade for the backstory
            if mainmenu.fade <= 255:
                mainmenu.fade += 5
            # cycles through the backstory using lists and draws them
            writing.set_alpha(mainmenu.fade)
            backstory.backstorylist[0][1] = writing
            backstory.backstorytalk(screen)

        # fade into game and backstory ----------
        if fadescreen:
            backstory.blackstory(screen)
            screen.blit(loadingscreen.blackfade, [0, 0])
            # begin backstory after faded out
            if mainmenu.fade <= 0:
                fadescreen = False
                backstory_begin = True

        pygame.display.flip()
        clock.tick(30)

    # after main game loop has been exited
    # (secret) boss fight
    if bossfight.bossfightbegin:
        bossfight.final()

    # after exiting boss fight, the previous game is cleared and a new game can be played
    if not mainmenu.pause:
        savefinal = mainmenu.finaltxt
        mainmenu.factoryreset(mobs, backstory, bossfight, healthbars, mainmenu, player)
        mainmenu.finaltxt = savefinal
    else:
        # if the game is paused
        pygame.mouse.set_visible(True)
        mainmenu.menu = True
