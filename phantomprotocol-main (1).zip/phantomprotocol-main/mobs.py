import random

from imageassets.Aimages import *
import mainmenu
pygame.init()

mobs_list_top = []
mob_xtop = []
mob_ytop = []
mob_hptop = []

mobs_list_bot = []
mob_xbot = []
mob_ybot = []
mob_hpbot = []

size = 32  # size of the mobs
mobanimation = 0

itemdraw = []
dropkey = 0
fallplace = 0

def mobcreation(x, y, hp, moblist):
    # fill the mobs lists with hp, location, boundaries, size
    for number in range(mainmenu.set_difficulty):
        x.append(random.choice([True, False]))
        y.append(True)
        hp.append(size)
        moblist.append([random.randrange(280, 2760), random.randrange(320, 545)])

# creates pygame.Rect for each mob
def mobhit(iteration, x_screen):
    global mob_rect_top, mob_rect_bot
    if mob_hptop[iteration]:
        mob_rect_top = pygame.Rect(mobs_list_top[iteration][0] + x_screen,
                                   mobs_list_top[iteration][1], size, size)

    if mob_hpbot[iteration]:
        mob_rect_bot = pygame.Rect(mobs_list_bot[iteration][0] + x_screen,
                                   mobs_list_bot[iteration][1], size, size)


def bunch_of_mobs(screen, move, mob_list, mobx, moby, mobhp, red, green):
    global dropkey, itemdraw, fallplace, mobanimation

    if mobanimation == len(floating_mobs):
        mobanimation = 0

    for mobnumber in range(len(mob_list)):
        mob_speed = random.randrange(1, 4)
        if mobhp[mobnumber]:
            screen.blit(floating_mobs[int(mobanimation)], [mob_list[mobnumber][0] + move, mob_list[mobnumber][1]])

        # mobs turn when moving further than 2760 width
        if mob_list[mobnumber][0] > 2760:
            mobx[mobnumber] = False
        # mobs move right
        if mobx[mobnumber]:
            mob_list[mobnumber][0] += mob_speed + 5
        # mobs move to the left
        if not mobx[mobnumber]:
            mob_list[mobnumber][0] -= mob_speed + 5
        # mobs turn when moving less than 280 width
        if mob_list[mobnumber][0] < 10:
            mobx[mobnumber] = True

        # mobs turn when moving further than 565 length
        if mob_list[mobnumber][1] > 565:
            moby[mobnumber] = False
        # mobs move up
        if moby[mobnumber]:
            mob_list[mobnumber][1] += mob_speed
        # mobs move down
        if not moby[mobnumber]:
            mob_list[mobnumber][1] -= mob_speed
        # mobs turn when moving less than 320 width
        if mob_list[mobnumber][1] < 320:
            moby[mobnumber] = True

        if mobhp[mobnumber]:
            # hp bar
            pygame.draw.rect(screen, red, [mob_list[mobnumber][0] - 2 + move, mob_list[mobnumber][1] - 7, size, 5])
            pygame.draw.rect(screen, green, [mob_list[mobnumber][0] - 2 + move, mob_list[mobnumber][1] - 7,
                                             mobhp[mobnumber], 5])

def mobkey(mobhp, mobnumber, mob_list):
    global dropkey, fallplace
    if mobhp[mobnumber] == 0:
        mobhp[mobnumber] = None
        dropkey = random.randrange(1, 5)
        # 1/4 chance of dropping key
        if dropkey == 1 and len(itemdraw) == 0:
            itemdraw.extend((mob_list[mobnumber][0], mob_list[mobnumber][1]))
            fallplace = random.randrange(507, 578)
        elif dropkey == 2 and len(itemdraw) == 0:
            itemdraw.extend((mob_list[mobnumber][0], mob_list[mobnumber][1]))
            fallplace = random.randrange(507, 578)

def checkmobkey():
    for anything in range(len(mob_hpbot)):
        if mob_hpbot[anything] is not None:
            if mob_hpbot[anything] <= 0:
                mob_hpbot[anything] = 0
        if mob_hptop[anything] is not None:
            if mob_hptop[anything] <= 0:
                mob_hptop[anything] = 0

    # somehow works LOLLL
    if 0 in mob_hpbot:
        for checking in range(len(mob_hpbot)):
            mobkey(mob_hpbot, checking, mobs_list_bot)
    elif 0 in mob_hptop:
        for checking in range(len(mob_hptop)):
            mobkey(mob_hptop, checking, mobs_list_top)

def clearmobs():
    # clear hp list
    mob_hptop.clear()
    mob_hpbot.clear()
    # clear location list
    mobs_list_top.clear()
    mobs_list_bot.clear()
    # clear bounce x list
    mob_xtop.clear()
    mob_xbot.clear()
    # clear bounce y list
    mob_ytop.clear()
    mob_ybot.clear()
