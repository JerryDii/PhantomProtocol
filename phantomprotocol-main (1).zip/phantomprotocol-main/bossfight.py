from imageassets.Aimages import *
import mainmenu
import healthbars
import sys
import player
import weapons
import backstory
import importlib
pygame.init()

screen = pygame.display.set_mode([1067, 600])
pygame.display.set_caption(" Phantom Protocol")
pygame.display.set_icon(phantomicon)
clock = pygame.time.Clock()

key = 0
bossfightbegin = False
storyseq = 0
imagenumber = 0

dark = pygame.Surface((1067, 500))
dark.fill((111, 81, 207))
floordark = pygame.Surface((1067, 120))
floordark.fill((64, 60, 180))
player_rect = pygame.Rect(0, 0, 0, 0)

jump = False
walking = 0
walkdown = False
rightwalk = -230
bossbackstory = True
exitloop = False

# when finished don't forget to add a screen and clock and delete the one here
def final():
    global rightwalk, player_rect, bossfightbegin, storyseq, walking, walkdown, jump, \
        bossbackstory, exitloop, imagenumber

    if rightwalk == -230:
        importlib.reload(player)
        pygame.mouse.set_visible(True)
        jump = False
        mainmenu.fade = 0

    while bossfightbegin:
        if healthbars.playerhp <= 0 or mainmenu.restart:
            mainmenu.overscreen = True
            bossfightbegin = False
            mainmenu.finaltxt = True

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DELETE:
                    mainmenu.overscreen = True
                    bossfightbegin = False
                    mainmenu.finaltxt = True

                elif event.key == pygame.K_ESCAPE and mainmenu.fade >= 255:
                    pygame.mouse.set_visible(True)
                    mainmenu.pause = True
                    exitloop = True

                if event.key == pygame.K_e:
                    # press e to switch between weapons
                    if weapons.current_weapon == "sword":
                        weapons.current_weapon = "gun"
                    elif weapons.current_weapon == "gun":
                        weapons.current_weapon = "mouse"
                        pygame.mouse.set_visible(True)
                    elif weapons.current_weapon == "mouse":
                        weapons.current_weapon = "sword"

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse = pygame.mouse.get_pos()
                print(mouse)

                if bossbackstory and mainmenu.fade > 255 and storyseq != 2:
                    storyseq += 1

                if not bossbackstory:
                    weapons.swordwoosh.play()
                    weapons.swordforward = True

                    if weapons.current_weapon == "gun" and len(weapons.bulletlist) <= 19:
                        weapons.bulletlist.append([weapons.weaponx + 15, weapons.weapony - 5])

                    # check if the sword has hit the boss
                    elif weapons.current_weapon == "sword":
                        if swordrect.colliderect(bosshitbox) or swordrect.colliderect(bosshitbox2):
                            healthbars.bosshp -= 3

        # WASD
        movescreen = pygame.key.get_pressed()

        if storyseq == 2:
            if movescreen[pygame.K_w] and player.pos_y == 390:
                jump = True

            # move to the left
            if movescreen[pygame.K_a] and rightwalk >= -60:
                rightwalk -= 6
                player.player.run()
                if not walkdown:
                    walking += 0.5

            # move to the right
            elif movescreen[pygame.K_d] and rightwalk <= 670:
                rightwalk += 6
                player.player.run()
                if not walkdown:
                    walking += 0.5

            else:
                player.player.stoprun()

        swordmouse = pygame.mouse.get_pos()
        weapons.weapony = swordmouse[1]
        if swordmouse[0] < (rightwalk - 100):
            weapons.weaponx = rightwalk - 100
        elif (rightwalk + 326) < swordmouse[0]:
            weapons.weaponx = rightwalk + 326
        else:
            weapons.weaponx = swordmouse[0]

        # calcs ---------------------------------
        if storyseq == 0:
            player.player.run()
            if rightwalk <= 0:
                rightwalk += 5
                player.moving_sprites.update(0.3, rightwalk)

        elif storyseq == 2:
            player_rect = pygame.Rect(122 + rightwalk, player.pos_y + 10, 64, 160)

            if walking > 2.5 and not walkdown:
                walkdown = True
            if walkdown:
                walking -= 0.7
                if walking <= 0:
                    walkdown = False

            if jump:
                player.expo += 0.15
                player.pos_y -= 10 / player.expo
                if player.pos_y <= 200:
                    player.expo = 0
                    jump = False

            if not jump and player.pos_y != 390:
                player.pos_y += 10 * player.expo
                player.expo += 0.15
                if player.pos_y >= 400:
                    player.pos_y = 390
                    player.expo = 0

            weapons.swordstab()
            glow.set_alpha(weapons.addglow)
            weapons.pulse()

        # break out of the loop so there is no lag before the lose/win screen
        if mainmenu.overscreen or mainmenu.winscreen:
            break
        if exitloop:
            exitloop = False
            break

        bosshitbox = pygame.Rect(824, 285, 102, 282)
        bosshitbox2 = pygame.Rect(921, 300, 200, 228)
        for something in range(len(weapons.bulletlist)):
            bulletrect = pygame.Rect(weapons.bulletlist[something][0], weapons.bulletlist[something][1], 19, 5)
            if bosshitbox.colliderect(bulletrect):
                weapons.bulletlist[something][0] = 3851
                healthbars.bosshp -= 1.5

        swordrect = pygame.Rect(weapons.weaponx + 16, weapons.weapony - 12, 52, 24)

        # draw -----------------------------------
        screen.blit(forestbg, [0, 0])
        screen.blit(floorbg, [0, 500])
        screen.blit(floorbg, [0, 570])

        screen.blit(boss_animations[imagenumber], [815, 205])
        imagenumber += 1
        if imagenumber >= len(boss_animations):
            imagenumber = 0

        player.moving_sprites.draw(screen)

        if storyseq == 2:
            spikes()
            player.moving_sprites.update(0.3, rightwalk)

            healthbars.playerhpbar(screen, RED, GREEN, walking, rightwalk)
            if rightwalk >= 670:
                healthbars.playerhp -= 3

            healthbars.bosshpbar(screen, RED, GREEN)

            if weapons.current_weapon == "sword":
                weapons.weaponchoice(screen, weapons.weaponx, weapons.weapony, daggerimg)
            elif weapons.current_weapon == "gun":
                weapons.weaponchoice(screen, weapons.weaponx, weapons.weapony, gunimg)

        if not bossbackstory:
            weapons.bullets(screen, 0)

        screen.blit(dark, [0, 0], None, pygame.BLEND_MULT)
        screen.blit(floordark, [0, 500], None, pygame.BLEND_MULT)

        if bossbackstory:
            if rightwalk == 5:
                backstory.blackstory(screen)
                if mainmenu.fade <= 255:
                    mainmenu.fade += 5
                    bossstory1.set_alpha(mainmenu.fade)

                if storyseq == 0:
                    screen.blit(bossstory1, [0, 0])
                elif storyseq == 1:
                    screen.blit(bossstory2, [0, 0])
                elif storyseq == 2:
                    bossbackstory = False

        if healthbars.bosshp <= 0:
            mainmenu.winscreen = True
            bossfightbegin = False
            mainmenu.finaltxt = True

        pygame.display.flip()
        clock.tick(30)


spikex = 0
spikey = 600
spikewait = 0
spikedrawn = False
spikeoff = -20
spikespeed = 30
spikeout = 0
spikesound = False
spikerect = pygame.Rect(0, 0, 0, 0)

if mainmenu.set_difficulty == 3:
    spikespeed = 30
elif mainmenu.set_difficulty == 7:
    spikespeed = 25
elif mainmenu.set_difficulty == 15:
    spikespeed = 20

def spikes():
    global spikedrawn, spikeoff, spikewait, spikex, spikeout, spikesound, spikey, spikerect

    if not spikedrawn:
        spikeoff += 1

        if spikeoff == spikespeed - 20:
            spikex = rightwalk + 90
            spikewait, spikeoff = 0, 0
            spikedrawn, spikesound = True, True

    elif spikedrawn:
        if player_rect.colliderect(spikerect):
            healthbars.playerhp -= 0.5

        screen.blit(baseshadow, [spikex, 430])
        if spikeout != spikespeed - 20:
            spikeout += 1

        elif spikeout == spikespeed - 20:
            if spikesound:
                weapons.swordwoosh.play()
                spikesound = False

            screen.blit(spikepng, [spikex, spikey])
            screen.blit(floorbg, [0, 570])
            screen.blit(covershadow, [spikex, 430])
            spikerect = pygame.Rect(spikex + 23, spikey + 38, 48, 86)

            if spikey <= 420:
                spikey = 430
            else:
                if spikewait != spikespeed:
                    if spikey != 430:
                        spikey -= 30
                    elif spikey == 430:
                        spikewait += 1

            if spikewait == spikespeed:
                if spikey <= 550:
                    spikey += 30
                    if spikey > 560:
                        spikey = 600
                        spikeout, spikex = 0, 0
                        spikedrawn = False
