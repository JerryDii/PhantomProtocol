from imageassets.Aimages import *
import mobs

current_weapon = "sword"
stab = 0
swordforward = False
weaponx = 136
weapony = 498

swordwoosh = pygame.mixer.Sound("playerimages/swordsound.wav")
swordrect = [-1, 0, 0, 0]

bulletlist = []

addglow = 100
glowon = False
def pulse():
    global addglow, glowon
    if addglow >= 255:
        glowon = False
    elif addglow <= 100:
        glowon = True

    if not glowon:
        addglow -= 8
    elif glowon:
        addglow += 10

def weaponchoice(screen, x, y, weapon):
    global swordrect

    pygame.mouse.set_visible(False)

    swordrect = [x + 16, y - 12, 52, 24]
    screen.blit(glow, [x + stab - 30, y - 23])
    screen.blit(weapon, [x + stab - 12, y - 23])
    screen.blit(glow, [x + stab - 35, y - 23])

def swordstab():
    global stab, swordforward
    if swordforward:
        stab += 3
        if stab > 13:
            stab = 0
            swordforward = False

def bullets(screen, move):
    for something in range(len(bulletlist)):
        if len(bulletlist) == 20 and bulletlist[19][0] > 1067:
            bulletlist.clear()
            break
        elif bulletlist[something][0] > 3850:
            bulletlist[something][0] = 3851
        if bulletlist[something][0] != 3851:
            bulletlist[something][0] += 50

        pygame.draw.rect(screen, (82, 30, 112),
                             [bulletlist[something][0] + move, bulletlist[something][1], 19, 5])

def checkhit(weapon, hit, hplost):
    # some mobs are drawn below the player, some above
    if mobs.mob_hpbot[hit]:
        if mobs.mob_rect_bot.colliderect(weapon):
            mobs.mob_hpbot[hit] -= hplost  # must be divisible by size
    if mobs.mob_hptop[hit]:
        if mobs.mob_rect_top.colliderect(weapon):
            mobs.mob_hptop[hit] -= hplost

def checkbullet(move):
    for something in range(len(bulletlist)):
        for elsething in range(len(mobs.mobs_list_bot)):
            mobs.mobhit(elsething, move)
            bulletrect = pygame.Rect(bulletlist[something][0] + move, bulletlist[something][1], 19, 5)

            if mobs.mob_hpbot[elsething]:
                if mobs.mob_rect_bot.colliderect(bulletrect):
                    # must be divisible by size
                    bulletlist[something][0] = 3851
                    if mobs.mob_hpbot[elsething] is not None:
                        mobs.mob_hpbot[elsething] -= 3

    for something in range(len(bulletlist)):
        for elsething in range(len(mobs.mobs_list_top)):
            mobs.mobhit(elsething, move)
            bulletrect = pygame.Rect(bulletlist[something][0] + move, bulletlist[something][1], 19, 5)

            if mobs.mob_hptop[elsething]:
                if mobs.mob_rect_top.colliderect(bulletrect):
                    bulletlist[something][0] = 3851
                    if mobs.mob_hptop[elsething] is not None:
                        mobs.mob_hptop[elsething] -= 3
