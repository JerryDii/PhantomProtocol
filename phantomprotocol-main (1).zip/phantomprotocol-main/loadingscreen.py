import pygame
pygame.init()

loadingwait = 0

# fade template
# originally going to make a loading screen but ran out of time
blackfade = pygame.Surface([1067, 600])
def fade_template(mainmenu):
    blackfade.fill((0, 0, 0))
    blackfade.set_alpha(mainmenu.fade)
    mainmenu.fade -= 5
