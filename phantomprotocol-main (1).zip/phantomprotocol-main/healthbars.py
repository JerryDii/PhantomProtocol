from imageassets.Aimages import *
import player

pygame.init()

# hp bar
playerhp = 100
increasehp = 0

bosshp = 200


def playerhpbar(screen, red, green, walking, x):
    pygame.draw.rect(screen, red, [105 + x, player.pos_y - 7 + walking, 100, 10])
    pygame.draw.rect(screen, green, [105 + x, player.pos_y - 7 + walking, playerhp, 10])

def bosshpbar(screen, red, green):
    pygame.draw.rect(screen, red, [860, 237, 200, 20])
    pygame.draw.rect(screen, green, [860, 237, bosshp, 20])

def mobdamage_place(player, place):
    global playerhp
    # mob damaging user cooldown
    if player.colliderect(place):
        playerhp -= 0.4

def healthpotion():
    global playerhp, increasehp
    if playerhp < 100:
        if (100 - playerhp) < 50:
            playerhp += 100 - playerhp
        else:
            playerhp += 50

itemrect = 0
def itemdrop(item, screen, x, y, length, width):
    global itemrect
    for anything in range(2):
        screen.blit(glow, [x - 25, y - 5])

    itemrect = pygame.Rect(x, y + 12, length, width)

    screen.blit(item, [x, y])
