import pygame
pygame.init()
# you may wonder, why "Aimages"? I need it at the top of the folder...

# colours for main game
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 200, 0)
RED = (220, 0, 0)

# main game image assets
hallwaybg = pygame.image.load("imageassets/hallway.png")
hallwaybg = pygame.transform.smoothscale(hallwaybg, [3831, 600])
forestbg = pygame.image.load("imageassets/forestbg.jpg")
forestbg = pygame.transform.smoothscale(forestbg, [1200, 650])
floorbg = pygame.image.load("imageassets/floorbg.png")
floorbg = pygame.transform.scale(floorbg, [1067, 1067])

# player sprites for running (bruh)
player1 = pygame.image.load("playerimages/walking1.png")
player1 = pygame.transform.scale(player1, [192, 173])
player2 = pygame.image.load("playerimages/walking2.png")
player2 = pygame.transform.scale(player2, [192, 173])
player3 = pygame.image.load("playerimages/walking3.png")
player3 = pygame.transform.scale(player3, [192, 173])
player4 = pygame.image.load("playerimages/walking4.png")
player4 = pygame.transform.scale(player4, [192, 173])
player5 = pygame.image.load("playerimages/walking5.png")
player5 = pygame.transform.scale(player5, [192, 173])
player6 = pygame.image.load("playerimages/walking6.png")
player6 = pygame.transform.scale(player6, [192, 173])
player7 = pygame.image.load("playerimages/walking7.png")
player7 = pygame.transform.scale(player7, [192, 173])
player8 = pygame.image.load("playerimages/walking8.png")
player8 = pygame.transform.scale(player8, [192, 173])

jump1 = pygame.image.load("playerimages/jump1.png")
jump1 = pygame.transform.scale(jump1, [192, 173])
jump2 = pygame.image.load("playerimages/jump2.png")
jump2 = pygame.transform.scale(jump2, [192, 173])
jump3 = pygame.image.load("playerimages/jump3.png")
jump3 = pygame.transform.scale(jump3, [192, 173])
jump4 = pygame.image.load("playerimages/jump4.png")
jump4 = pygame.transform.scale(jump4, [192, 173])
jump5 = pygame.image.load("playerimages/jump5.png")
jump5 = pygame.transform.scale(jump5, [192, 173])
jump6 = pygame.image.load("playerimages/jump6.png")
jump6 = pygame.transform.scale(jump6, [192, 173])
jump7 = pygame.image.load("playerimages/jump7.png")
jump7 = pygame.transform.scale(jump7, [192, 173])

# mob sprites for floating
floating_mobs = []
mob1 = pygame.image.load("mobimages/mob1.png")
mob2 = pygame.image.load("mobimages/mob2.png")
mob3 = pygame.image.load("mobimages/mob3.png")
mob4 = pygame.image.load("mobimages/mob4.png")
mob5 = pygame.image.load("mobimages/mob5.png")
mob6 = pygame.image.load("mobimages/mob6.png")
mob7 = pygame.image.load("mobimages/mob7.png")
mob8 = pygame.image.load("mobimages/mob8.png")
for anything in range(3):
    floating_mobs.extend([mob1, mob1, mob2, mob3, mob4, mob5, mob5])
floating_mobs.extend([mob1, mob1, mob2, mob6, mob7, mob7, mob8])

bossimage1 = pygame.image.load("mobimages/boss1.png")
bossimage2 = pygame.image.load("mobimages/boss2.png")
bossimage3 = pygame.image.load("mobimages/boss3.png")
boss_animations = []

for manythings in range(100):
    boss_animations.append(bossimage1)
boss_animations.append(bossimage2)
boss_animations.extend((bossimage3, bossimage3, bossimage3, bossimage3, bossimage3, bossimage3, bossimage3))

baseshadow = pygame.image.load("mobimages/bossshadow1.png")
spikepng = pygame.image.load("mobimages/bossspike.png")
covershadow = pygame.image.load("mobimages/bossshadow2.png")

keyimg = pygame.image.load("imageassets/key.png")
potionimg = pygame.image.load("imageassets/healthpotion.PNG")
glow = pygame.image.load("imageassets/glow.png")
glow = pygame.transform.scale(glow, [80, 45])
glow.fill((100, 100, 100), special_flags=pygame.BLEND_RGB_ADD)

daggerimg = pygame.image.load("imageassets/dagger.PNG")
gunimg = pygame.image.load("imageassets/gun.png")

city = pygame.image.load("imageassets/citybg.png")
city = pygame.transform.smoothscale(city, [1067, 600])

citybox = pygame.image.load("imageassets/rectbg.png")
citybox = pygame.transform.smoothscale(citybox, [1067, 184])

titletext = pygame.image.load("imageassets/phantom protocol.png")
titletext = pygame.transform.smoothscale(titletext, [475, 35])
titlealpha = 255
titleback = False

playtext = pygame.image.load("imageassets/PLAY.png")
playtext = pygame.transform.smoothscale(playtext, [38, 9])
playrect = pygame.Rect(649, 532, 70, 47)
playbox = pygame.Surface([70, 47])
backtomenu = pygame.Rect(680, 275, 300, 50)

settingstext = pygame.image.load("imageassets/SETTINGS.png")
settingstext = pygame.transform.smoothscale(settingstext, [74, 11])
settingsrect = pygame.Rect(876, 532, 104, 47)
settingsbox = pygame.Surface([104, 47])

difficulty_button1 = pygame.Rect(276.46, 279.24, 42, 42)
difficulty_button2 = pygame.Rect(361.82, 279.24, 42, 42)
difficulty_button3 = pygame.Rect(447.18, 279.24, 42, 42)
volume_slider = pygame.Rect(276.2, 201.64, 477.93, 20.01)

instructionstext = pygame.image.load("imageassets/INSTRUCTIONS.png")
instructionstext = pygame.transform.smoothscale(instructionstext, [113, 11])
instructionsrect = pygame.Rect(725, 532, 143, 47)
instructionsbox = pygame.Surface([143, 47])

phantomicon = pygame.image.load("imageassets/phantomicon.png")
phantomicon = pygame.transform.scale(phantomicon, [33, 33])

settingsbg = pygame.image.load("imageassets/MENUSETTINGS.png")
settingsbg = pygame.transform.scale(settingsbg, (1067, 600))

instructionbg = pygame.image.load("imageassets/MENUINSTRUCTIONS.png")
instructionbg = pygame.transform.scale(instructionbg, (1067, 600))

writing = pygame.image.load("playerimages/writing.png")
anger = pygame.image.load("playerimages/anger.png")
nervous = pygame.image.load("playerimages/nervous.png")
determination = pygame.image.load("playerimages/determination.png")
defeated = pygame.image.load("playerimages/defeat.png")
smile = pygame.image.load("playerimages/smile.png")

backstory1 = pygame.image.load("playerimages/text1.png")
backstory2 = pygame.image.load("playerimages/text2.png")
backstory3 = pygame.image.load("playerimages/text3.png")
backstory4 = pygame.image.load("playerimages/text4.png")
backstory5 = pygame.image.load("playerimages/text5.png")
backstory6 = pygame.image.load("playerimages/text6.png")

loseimg = pygame.image.load("imageassets/gameover.png")
loseimg = pygame.transform.smoothscale(loseimg, [1067, 600])
losetxt = pygame.image.load("playerimages/losetxt.png")
winimg = pygame.image.load("imageassets/winner.png")
winimg = pygame.transform.smoothscale(winimg, [1067, 600])
wintxt = pygame.image.load("playerimages/wintxt.png")

bossstory1 = pygame.image.load("playerimages/text7.png")
bossstory2 = pygame.image.load("playerimages/text8.png")
