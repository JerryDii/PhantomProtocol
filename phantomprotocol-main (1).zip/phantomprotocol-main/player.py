from imageassets.Aimages import *

pos_y = 390
expo = 0
turn = False
turnback = False

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.run_animation = False
        self.sprites = []

        for something in range(3):
            self.sprites.append(player1)
            self.sprites.append(player2)
            self.sprites.append(player5)
            self.sprites.append(player6)
            self.sprites.append(player7)
            self.sprites.append(player8)
        self.sprites.append(player1)
        self.sprites.append(player2)
        self.sprites.append(player3)
        self.sprites.append(player4)
        self.sprites.append(player5)
        self.sprites.append(player6)
        self.sprites.append(player7)

        self.sprites.append(jump1)
        self.sprites.append(jump2)
        self.sprites.append(jump2)
        self.sprites.append(jump3)
        self.sprites.append(jump3)
        self.sprites.append(jump4)
        self.sprites.append(jump4)
        self.sprites.append(jump5)
        self.sprites.append(jump5)
        self.sprites.append(jump5)
        self.sprites.append(jump6)
        self.sprites.append(jump6)
        self.sprites.append(jump7)

        self.current_sprite = 1
        self.image = self.sprites[self.current_sprite]

        self.rect = self.image.get_rect()
        self.rect.topleft = [40, pos_y]

    def run(self):
        self.run_animation = True

    def stoprun(self):
        if pos_y == 390:
            self.current_sprite = 1
        self.run_animation = False

    def update(self, speed, x):
        global backturn, turn, dagger, pos_y

        if pos_y != 390:
            if int(self.current_sprite) < 25:
                self.current_sprite = 25
            self.current_sprite += 0.5
            if int(self.current_sprite) >= len(self.sprites):
                self.current_sprite = 0

        elif self.run_animation and pos_y == 390:
            self.current_sprite += speed
            if int(self.current_sprite) >= 25:
                self.current_sprite = 0

        self.rect = self.image.get_rect()
        self.rect.topleft = [40 + x, pos_y]

        self.image = self.sprites[int(self.current_sprite)]


# Creating the sprites and groups
moving_sprites = pygame.sprite.Group()
player = Player()
moving_sprites.add(player)

