from imageassets.Aimages import *
import weapons
import sys
import loadingscreen
import importlib

pygame.init()

menu = True
blackscreen = False
pause = False
fade = 0
volume = 1
volumebar = 754.13

# 3 is easy, 7 is medium, 15 is hard
set_difficulty = 3

instructions = False
mainmenuscreen = True
settings = False

restart = False
overscreen = False
winscreen = False
finaltxt = False

def buttonhover(boxtype):
    boxtype.set_alpha(55)
    boxtype.fill((255, 255, 255))

def musicplay():
    global music
    music = pygame.mixer.Sound("imageassets/music.ogg")
    music.play(-1)

def musicvolume():
    pygame.mixer.Sound.set_volume(music, volume)
    pygame.mixer.Sound.set_volume(weapons.swordwoosh, volume - volume/2)

def firstmenu(screen, clock):
    global menu, titleback, titlealpha, playrect, settingsrect, instructionsrect, blackscreen, fade, \
        instructions, settings, mainmenuscreen, volumebar, set_difficulty, volume, pause, restart, overscreen, winscreen, finaltxt

    # begin menu loop ----------
    while menu:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

            elif event.type == pygame.KEYDOWN and not overscreen and not winscreen:
                if event.key == pygame.K_DELETE and fade == 300:
                    pause = False
                    menu = False
                    restart = True
                    finaltxt = True

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse = pygame.mouse.get_pos()
                print(mouse)

                if overscreen:
                    if finaltxt:
                        finaltxt = False
                    elif backtomenu.collidepoint(mouse) and not finaltxt:
                        overscreen = False
                elif winscreen:
                    if finaltxt:
                        finaltxt = False
                    elif backtomenu.collidepoint(mouse) and not finaltxt:
                        winscreen = False

                else:
                    if mainmenuscreen:
                        if playrect.collidepoint(mouse):
                            if pause:
                                menu = False
                            else:
                                blackscreen = True

                        elif instructionsrect.collidepoint(mouse):
                            instructions = True
                            mainmenuscreen = False
                            exit_button = pygame.Rect(79, 470.59, 119, 50)

                        elif settingsrect.collidepoint(mouse):
                            settings = True
                            mainmenuscreen = False
                            exit_button = pygame.Rect(75, 492, 118, 50)

                    elif instructions:
                        if exit_button.collidepoint(mouse):
                            instructions = False
                            mainmenuscreen = True

                    elif settings:
                        if not pause:
                            if difficulty_button1.collidepoint(mouse):
                                set_difficulty = 3
                            elif difficulty_button2.collidepoint(mouse):
                                set_difficulty = 7
                            elif difficulty_button3.collidepoint(mouse):
                                set_difficulty = 15

                        if volume_slider.collidepoint(mouse):
                            volumebar = pygame.mouse.get_pos()[0]
                            volume = (volumebar - 276.2) / 477.93
                            musicvolume()

                        if exit_button.collidepoint(mouse):
                            settings = False
                            mainmenuscreen = True

        # calcs ----------------
        hover = pygame.mouse.get_pos()
        buttonhover(playbox)
        buttonhover(instructionsbox)
        buttonhover(settingsbox)

        if titleback:
            titlealpha += 3
        else:
            titlealpha -= 4
        if titlealpha <= 110:
            titleback = True
        elif titlealpha >= 255:
            titleback = False

        # main menu ------------
        # backgrounds ---
        if mainmenuscreen:
            screen.blit(city, [0, 0])
            screen.blit(citybox, [0, 416.61])

            # title
            titletext.set_alpha(titlealpha)
            screen.blit(titletext, [100, 493])

            # button click box
            if playrect.collidepoint(hover):
                screen.blit(playbox, [649, 532])
                pygame.draw.rect(screen, (205, 205, 205), playrect, 1)
            elif instructionsrect.collidepoint(hover):
                screen.blit(instructionsbox, [725, 532])
                pygame.draw.rect(screen, (205, 205, 205), instructionsrect, 1)
            elif settingsrect.collidepoint(hover):
                screen.blit(settingsbox, [876, 532])
                pygame.draw.rect(screen, (205, 205, 205), settingsrect, 1)

            # buttons text
            screen.blit(playtext, [666, 551])
            screen.blit(instructionstext, [740, 550])
            screen.blit(settingstext, [891, 550])

        # instructions --------
        elif instructions:
            screen.blit(instructionbg, [0, 0])

        # settings ------------
        elif settings:
            screen.blit(settingsbg, [0, 0])
            pygame.draw.ellipse(screen, (0, 0, 0), [volumebar - 25, 190, 50, 50])

            if set_difficulty == 3:
                pygame.draw.rect(screen, (0, 0, 0), [280, 283, 36, 36])
            elif set_difficulty == 7:
                pygame.draw.rect(screen, (0, 0, 0), [365, 282, 36, 37])
            elif set_difficulty == 15:
                pygame.draw.rect(screen, (0, 0, 0), [450, 282, 37, 37])

        # begin game -----------
        if blackscreen and not pause:
            fade += 4
            loadingscreen.blackfade.set_alpha(fade)
            screen.blit(loadingscreen.blackfade, [0, 0])
        if fade >= 255 and not pause:
            menu = False

        # end game -------------
        if overscreen:
            screen.fill(BLACK)
            if finaltxt:
                screen.blit(losetxt, [0, 0])
            else:
                screen.blit(loseimg, [0, 0])
        elif winscreen:
            screen.fill(BLACK)
            if finaltxt:
                screen.blit(wintxt, [0, 0])
            else:
                screen.blit(winimg, [0, 0])

        pygame.display.flip()
        clock.tick(30)

def factoryreset(mobs, backstory, bossfight, healthbars, mainmenu, player):
    global volumebar, overscreen, winscreen
    # reset all variables for next game
    oversave1 = overscreen
    oversave2 = winscreen
    saved_volumebar = volumebar
    importlib.reload(mobs)
    importlib.reload(backstory)
    importlib.reload(bossfight)
    importlib.reload(healthbars)
    importlib.reload(loadingscreen)
    importlib.reload(mainmenu)
    importlib.reload(player)
    importlib.reload(weapons)
    pygame.mouse.set_visible(True)
    volumebar = saved_volumebar
    overscreen = oversave1
    winscreen = oversave2
