from imageassets.Aimages import *
import mainmenu
pygame.init()
pygame.font.init()

# enough for 5 text sequences, the last item in this list moves onto the real game
backstorylist = [[True, writing, backstory1], [False, anger, backstory2], [False, nervous, backstory3],
                 [False, determination, backstory4], [False, defeated, backstory5], [False, smile, backstory6],
                 [False, None]]

# cycle through backstory
def backstorycheck(current, next):
    backstorylist[current][0] = False
    backstorylist[next][0] = True

def backstoryseq():
    for storynumber in range(len(backstorylist)):
        if backstorylist[storynumber][0]:
            backstorycheck(storynumber, storynumber + 1)
            break

def blackstory(screen):
    screenshadow = pygame.Surface([1067, 600])
    screenshadow.fill(BLACK)
    screenshadow.set_alpha(150)
    screen.blit(screenshadow, [0, 0])

wait = 0
def backstorytalk(screen):
    global wait
    if wait < 66:
        wait += 1

    blackstory(screen)
    for storynumber in range(len(backstorylist)):
        if backstorylist[storynumber][0]:
            screen.blit(backstorylist[storynumber][1], [0, 0])
            if wait == 66:
                mainmenu.fade = 300
                screen.blit(backstorylist[storynumber][2], [0, 5])
